App = {
  web3Provider: null,
  contracts: {},

  initWeb3: async function () {
    if (window.ethereum) {
    App.web3Provider = window.ethereum;
    try {
    await window.ethereum.enable();
    } catch (error) {
    console.error("User denied account access")
    }
    }
    else if (window.web3) {
    App.web3Provider = window.web3.currentProvider;
    }
    else {
    App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
    }
    web3 = new Web3(App.web3Provider);
    return App.initContract();
    },


  initContract: function () {
    $.getJSON('Registry.json', function (data) {
      let AdoptionArtifact = data;
      App.contracts.Adoption = TruffleContract(AdoptionArtifact);
      App.contracts.Adoption.setProvider(App.web3Provider);
    });
    return App.bindEvents();
  },

  bindEvents: function () {
    $(document).on('click', '.btn-setVal', App.setVal);
    $(document).on('click', '.btn-getVal', App.getVal);
  },


  setVal: function () {
    let val = $("#val").val();
    App.contracts.Adoption.deployed().then(function (instance) {
      let adoptionInstance = instance;
      return adoptionInstance.setVal(val);
    }).catch(function (err) {
      console.log(err.message);
    });
  },

  getVal: function () {
    App.contracts.Adoption.deployed().then(function (instance) {
      let adoptionInstance = instance;
      return adoptionInstance.val.call();
    }).then(function (result) {
      alert('Val: ' + result);
    }).catch(function (err) {
      console.log(err.message);
    });
  },

};

$(function () {
  $(window).load(function () {
    App.initWeb3();
  });
});
